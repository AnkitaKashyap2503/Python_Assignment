#Level I- Question 12

num = int(input("Sample input: "))

unit = 0
final = 0

# This will calculate until the last digit does not become 0
while num >= 1:
    unit = num % 10
    final = unit + (final * 10)
    num = num // 10


print("Sample Output: ", final)
