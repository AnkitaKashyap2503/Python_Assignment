#Level I- Question 6

x = int(input("Enter a number:"))

sum = 0
for i in range(1,x):
    if x%i == 0:
        sum = sum + i

if x == sum:
    print("Yes")
else:
    print("No")