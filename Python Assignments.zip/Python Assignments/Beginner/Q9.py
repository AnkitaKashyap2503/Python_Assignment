#Level I- Question 9

#User input for elements in list
x = int(input("Enter the number of elements: "))
list = []
dict = {}

for i in range (x):
    a = int(input("Enter a number: "))
    list.append(a)

print("Input list: ", list)
list = sorted(list)

for i in list:
    b = list.count(i)
    dict[i] = b

print("Frequency count: ", dict)
