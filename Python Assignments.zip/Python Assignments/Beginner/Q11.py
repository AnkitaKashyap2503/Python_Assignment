#Level I- Question 11

num = int(input("Enter a number: "))

#Function to add all the digits in the given number
def addition(x):
    sum = 0
    last_digit = 0
    while x >=1:
        last_digit = x%10
        sum += last_digit
        x = x//10
    return sum

#Check the addition of all digits for the 1st time
result = addition(num)
print("Sum_of_digits: ", result)

#Loop for all the other times until we get a sigle digit for the addition
while result >= 10:
    result = addition(result)


print("Final_Output: ", result)
