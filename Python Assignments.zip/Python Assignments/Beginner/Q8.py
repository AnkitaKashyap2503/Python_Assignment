#Level I- Question 8

x = int(input("Enter the first number: "))
y = int(input("Enter the second number: "))

factors = 0
x_factors = [1]

i = 0
while i <= 500:       #This number can be changed in later updates of the code (depending on the scope of the code)
    factors = factors + x
    x_factors.append(factors)
    i += 1

factors2 = 0
y_factors = [1]
j = 0
while j <= 500:
    factors2 = factors2 + y
    y_factors.append(factors2)
    j += 1

for i in x_factors:
    if i == 1:
        continue
    if i in y_factors:
# The smallest common number in both the lists is the LCM
        print(f"LCM of {x} and {y} are: {i}")
        break
