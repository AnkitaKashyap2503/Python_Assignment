#Level I- Question 3

#Assuming Maximum score is 100
print("Enter the following scores out of 100")
P = int(input("Physics:"))
Ch = int(input("Chemistry:"))
B = int(input("Biology:"))
M = int(input("Mathematics:"))
Com = int(input("Computer:"))

#Percentage calculation
Sum = P + Ch + B + M + Com
Percentage = (Sum/500) * 100
print("Your final percentage is:",Percentage)

#Printing grade
if Percentage >= 90:
    print("Grade A")
elif Percentage >= 80:
    print("Grade B")
elif Percentage >= 70:
    print("Grade C")
elif Percentage >= 60:
    print("Grade D")
elif Percentage >= 40:
    print("Grade E")
elif Percentage <= 40:
    print("Grade F")
