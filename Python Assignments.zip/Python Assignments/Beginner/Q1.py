#Level I- Question 1

x = int(input("Please enter a number: "))

if x%3 == 0 | x%5 == 0:
    print ("Consultadd - Python Training")
elif x%3 == 0:
    print ("Consultadd")
elif x%5 == 0:
    print ("Python Training")