#Level I- Question 2

#User input for String
x = input("Please enter a string:")

#Initilizing the counters
alpha = 0
num = 0

#Counting number of Alphabets and digits
for i in x:
    if i.isalpha():
        alpha += 1
    elif i.isdigit():
        num += 1

print ("Alpha:", alpha)
print ("Num:", num)
print(f"Alphabet: {alpha} & Number: {num}")
