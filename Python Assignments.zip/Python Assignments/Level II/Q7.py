#Level II- Question 7

list1 = []
length = 0
b = 0
c = 0
d = 0
element1 = 0
element2 = 0
median = 0

#User input for list
x = int(input("Enter the number of elements in list: "))
for i in range (0,x):
    a = int(input("Enter a number: "))
    list1.append(a)

length = len(list1)
list1 = sorted(list1)

#Median is avg of middle 2 elements in case of even number of elements
if length%2 == 0:
    b = length // 2
    d = b - 1
    element1 = list1[d]
    element2 = list1[b]
    median = (element1 + element2)/2
#Median is the middle element in case of odd number of elements
else:
    c = length // 2
    median = list1[c]

print("Median is: ", median)
    