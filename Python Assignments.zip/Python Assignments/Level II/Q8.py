#Level II- Question 8

string = input("Enter a string: ")

def vowel(str):
    vowel_str = "AaEeIiOoUu"
    count = 0
    for i in str:
        if i in vowel_str:
            count = count + 1
    return count

count = vowel(string)
print("Number of vowels: ", count)