#Level II- Question 3

#User input for list
x = int(input("Enter the number of elements in the list: "))
l1 =[]
count = 0
for i in range(x):
    a = int(input("Enter a number in list: "))
    l1.append(a)

print("arr = ", l1)

#User input for the integer
k = int(input("Enter the integer K: "))

for i in l1:
    num = k - i
    if num in l1:
        count += 1

#Since the pair would be counted twice, divide it by 2
count = count//2

print("Pair count: ", count)