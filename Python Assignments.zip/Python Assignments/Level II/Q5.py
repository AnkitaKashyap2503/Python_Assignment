#Level II- Question 5

#User input for list
x = int(input("Enter the number of temperatures in the list to analyze: "))
l1 =[]
count = 0
for i in range(x):
    a = int(input("Enter a number in list: "))
    l1.append(a)

# Average
sum = sum(l1)
num = len(l1)
avg = 0
if num > 0:
    avg = sum/num

#Highest
high = max(l1)

#lowest
low = min(l1)

print("Average Temperature: ", avg)
print("Highest Temperature: ", high)
print("Lowest Temperature: ", low)