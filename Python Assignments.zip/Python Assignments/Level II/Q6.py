#Level II- Question 6

x = int(input("Enter a number to check: "))

if x == 0:
    print("This number is not a power of 2")
if x == 1:
    print("This number is a power of 2")

y = x%2  #Odd number
if y != 0:
    print("This number is not a power of 2")