#Level II- Question 4

#User input for list
x = int(input("Enter the number of elements in the list: "))
list1 =[]
count = 0
for i in range(x):
    a = int(input("Enter a number in list: "))
    list1.append(a)

length = len(list1)


d = int(input("Enter the number of rotations to the right D: "))
list2 = []
final =[]
if length < d:
    print("Length of list is smaller than the rotations")
else:
    for i in range(0,d,1):
        element = list1.pop(i)
        list2.append(element)
    final = list2.extend(list1)

print("arr = ", list1)
print("D = ", d)
print("arr after rotation = ", final)