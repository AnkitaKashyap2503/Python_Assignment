#Level II- Question 2

#User input for list
x = int(input("Enter the number of elements in first list: "))
l1 =[]
for i in range(x):
    a = int(input("Enter a number: "))
    l1.append(a)

print("Sample Input: list1 = ", l1)

#A function the takes input as the list and returns unique list
def unique_list(l1):
    final = []
    final = list(set(l1))
    return final

#Function call
result = unique_list(l1)

#final result
print("Sample Output: list2 =", result)