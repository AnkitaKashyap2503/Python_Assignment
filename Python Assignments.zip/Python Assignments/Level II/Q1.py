#Level II- Question 1

#User input for 1st list
x = int(input("Enter the number of elements in first list: "))
list1 =[]
for i in range(x):
    a = int(input("Enter a number: "))
    list1.append(a)

#User input for 2nd list
y = int(input("Enter the number of elements in second list: "))
list2 =[]
for i in range(y):
    b = int(input("Enter a number: "))
    list2.append(b)

#Print both the lists
print("Sample inputs:")
print("L1 = ", list1)
print("L2 = ", list2)

#Create a list with common numbers
final = []
for i in list1:
    if i in list2:
        final.append(i)
final = list(set(final))

print("Output: ", final)