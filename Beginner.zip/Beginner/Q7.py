#Level I- Question 7

x = input("Enter string 1: ")
y = input("Enter string 2: ")

#Conerting the input string into lowercase as comparision is case sensitive
x = x.lower()
y = y.lower()

x = sorted(x)
y = sorted(y)

if x == y:
    print(True)
else:
    print(False)