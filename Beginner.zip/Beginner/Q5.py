#Level I- Question 5

x = int(input("Enter the number to calcualte its factorial:"))

if x <= 0:   #Factorials are only for positive numbers
    print("Please try again and enter a positive number")
else: 
    fact = 1
    for i in range(1,x+1):
        fact = fact * i
    print("Factorial:", fact)