#Level I- Question 10

sentence = input("Input_sentence: ")

#Convert the string into list
list = sentence.split()
final_list =[]
final_sentence = ""

#Reverse the list
final_list = list[::-1]

#Convert the list back into string
for i in final_list:
    final_sentence = final_sentence + i + " "

print("Output after reverse: ", final_sentence)