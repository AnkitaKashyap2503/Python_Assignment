start = int(input("Enter the starting number:"))
s = int(input("Enter the last number:"))
stop = s + 1 #Range function does not incluse the stop number

total1 = 0
for i in range(start, stop):
    a = i % 2
    if a == 1:
        total1 = total1 + i

print("Sum of odd numbers:", total1)